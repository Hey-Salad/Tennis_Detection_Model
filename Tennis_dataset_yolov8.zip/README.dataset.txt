# My First Project > 2025-02-13 4:29pm
https://universe.roboflow.com/tennis-ball-5tkzs/my-first-project-f7ynl

Provided by a Roboflow user
License: CC BY 4.0

